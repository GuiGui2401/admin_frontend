export const PROJECT_NAME = 'Estuaire_Achats';
export const BASE_URL = 'http://api.estuiaireachat.fiacredev.com/';
export const WEBSITE_URL = 'http://estuaireachat.fiacredev.com/';
export const api_url = BASE_URL + '/api/v1/';
export const api_url_admin = BASE_URL + '/api/v1/dashboard/admin/';
export const export_url = BASE_URL + '/storage/';
export const IMG_URL = 'http://api.estuiaireachat.fiacredev.com/storage/images/';
export const MAP_API_KEY = 'AIzaSyAffUHSFli6kMnjkfJOKBGO6AN828ixJPo';
export const LNG = 10.407835;
export const LAT = 5.490131;

export const VAPID_KEY =
  'BGaujmeKRvelveVZi_vyRb7VAyq6p-78EcPlyZpO5QWZ_of9qvNW3X8Ca_ZmbdtdLSSbH_4fhJCDzDFrKLw8M4k';
export const STRIPE_PUBLISHABLE_KEY =
  'pk_test_51LaGXyLrMlc0ddAAYc8wxwq8eFj9HbgpvValjxRtg2OZzTJDwFz0ZmATL1TOqAWUFBM3CeHbI5Cny71MzkrAXRxa00XTCJArPr';
export const PAYPAL_KEY =
  'ARKhb_cfiyLAGikamzpXnWEiynGxcGeOkmuxWQ9i1CUztdQy3F_UT4C7vbtR6sfPQ3kxecBi_NL_UEDF';
export const PAYSTACK_KEY = 'pk_test_2ec2bc5ed445385489385b2fce6cddfbfb265914';
export const RAZORPAY_KEY = 'rzp_test_TMPwvQpYGAIMbU';
export const StripeApi = 'http://estuaireachat.fiacredev.com/api/create-stripe-session';
export const RazorpayApi = 'http://estuaireachat.fiacredev.com/api/create-razorpay-session';

export const API_KEY = 'AIzaSyD5aoKN8B5w-yYVO4YGwMNjfFXITjLDA7M';
export const AUTH_DOMAIN = 'e-commerce-54d38.firebaseapp.com';
export const PROJECT_ID = 'e-commerce-54d38';
export const STORAGE_BUCKET = 'e-commerce-54d38.firebasestorage.app';
export const MESSAGING_SENDER_ID = '894650340633';
export const APP_ID = '1:894650340633:web:83debc644605cc8d292188';
export const MEASUREMENT_ID = 'G-N0TZHJ6GJW';

export const RECAPTCHASITEKEY = '6LfLgLcqAAAAAJsi6OxAkyfSyI4iLRPGjpbo54yZ';
export const SUPPORTED_FORMATS = [
  'image/jpg',
  'image/jpeg',
  'image/png',
  'image/svg+xml',
  'image/svg',
];

export const DEMO_SELLER = 210; // seller_id
export const DEMO_SHOP = 599; // seller_id
export const DEMO_DELIVERYMAN = 375; // deliveryman_id
export const DEMO_MANEGER = 114; // deliveryman_id
export const DEMO_MODERATOR = 297; // deliveryman_id
export const DEMO_ADMIN = 107; // deliveryman_id
