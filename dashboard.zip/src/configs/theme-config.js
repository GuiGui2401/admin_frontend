export const THEME_CONFIG = {
  locale: 'en',
  topNavColor: '#3e82f7',
  headerNavColor: '',
  currentTheme: 'dark',
  direction: 'ltr',
  navCollapsed: false,
  parcelMode: false,
};
