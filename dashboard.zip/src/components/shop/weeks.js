export const weeks = [
  {
    title: 'monday',
    disabled: false,
  },
  {
    title: 'tuesday',
    disabled: false,
  },
  {
    title: 'wednesday',
    disabled: false,
  },
  {
    title: 'thursday',
    disabled: false,
  },
  {
    title: 'friday',
    disabled: false,
  },
  {
    title: 'saturday',
    disabled: false,
  },
  {
    title: 'sunday',
    disabled: false,
  },
];
