const statuses = [
  { name: 'new', id: '1', active: true },
  { name: 'accepted', id: '2', active: true },
  { name: 'ready', id: '3', active: true },
  { name: 'on_a_way', id: '4', active: true },
  { name: 'delivered', id: '5', active: true },
  { name: 'canceled', id: '6', active: true },
];

export default statuses;
