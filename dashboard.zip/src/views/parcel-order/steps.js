export const steps = [
  {
    title: 'sender.details',
    content: 'First-content',
  },
  {
    title: 'receiver.details',
    content: 'Second-content',
  },
  {
    title: 'parcel.details',
    content: 'Third-content',
  },
];
