export const weeks = [
  {
    title: 'monday',
    time: [],
  },
  {
    title: 'tuesday',
    time: [],
  },
  {
    title: 'wednesday',
    time: [],
  },
  {
    title: 'thursday',
    time: [],
  },
  {
    title: 'friday',
    time: [],
  },
  {
    title: 'saturday',
    time: [],
  },
  {
    title: 'sunday',
    time: [],
  },
];
