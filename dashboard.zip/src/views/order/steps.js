export const steps = [
  {
    title: 'User info',
    content: 'First-content',
  },
  {
    title: 'Product info',
    content: 'Second-content',
  },
  {
    title: 'Delivery info',
    content: 'Third-content',
  },
  {
    title: 'Invoice',
    content: 'Fourth-content',
  },
];
