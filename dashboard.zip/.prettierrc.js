module.exports = {
  semi: true,
  singleQuote: true,
  jsxSingleQuote: true,
}
